import brain_games.engine as engine
from brain_games.games import prime


def main():
    engine.run_game(prime)


if __name__ == "__main__":
    main()
